#version 330

#define MH_VERSION 5
#define MH_OFFSET 67
#define XP_HIDE false
#define XP_OFFSET vec3(-10600.0, -10600.0, -10600.0)
#define XP_COLOR vec3(0.501, 1.0, 0.125)
#define XP_COLOR_SHADOW vec3(0.0, 0.0, 0.0)

#moj_import <minecraft:globals.glsl>

// Function to convert a vertical ascent into a ID.
float get_id(float offset) {
    if (offset <= 0.0)
    return 0.0;
    return trunc(offset / 1000.0);
}

bool is_at(int offset, int vertex, int pos) { return (((vertex == 1 || vertex == 2) && offset == pos) || ((vertex == 0 || vertex == 3) && offset == (pos + 8))); }
bool is_at(int offset, int vertex, int pos0, int pos1) { return is_at(offset, vertex, pos0) || is_at(offset, vertex, pos1); }
bool is_at(int offset, int vertex, int pos0, int pos1, int pos2, int pos3) { return is_at(offset, vertex, pos0, pos1) || is_at(offset, vertex, pos2, pos3); }
bool within(vec3 a, vec3 b, float threshold) { return abs(length(a - b)) < threshold; }

void applyCustomHud() {
    vec3 pos = Position;
    vec2 guiSize = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    int guiScale = int(round(guiSize.x / (1 / ScreenSize.x)));

    float id = get_id((round(MH_OFFSET - pos.y)) * -1);

    // Detect if GUI text.
    if (id > 99 && Color.a != 0.0) {
        bool ffNightmareResponsive = int(id) == 100 || int(id) == 101 || int(id) == 102 || int(id) == 103 || int(id) == 104 || int(id) == 105 || int(id) == 106 || int(id) == 107 || int(id) == 108 || int(id) == 109 || int(id) == 110 || int(id) == 111 || int(id) == 112 || int(id) == 113 || int(id) == 114 || int(id) == 115 || int(id) == 100 || int(id) == 101 || int(id) == 102 || int(id) == 103 || int(id) == 104 || int(id) == 105 || int(id) == 106 || int(id) == 107 || int(id) == 108 || int(id) == 109 || int(id) == 110 || int(id) == 111 || int(id) == 112 || int(id) == 113 || int(id) == 114 || int(id) == 115;
        float yOffset = 0.0;
        float xOffset = 0.0;
        float layer = 0.0;
        vec2 scale = vec2(1, 1);
        bool outlined = false;

        switch (int(id)) {
    case 100:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+160;
                        yOffset = int(guiSize.y * (100.0/100))-8;
                        layer = 1.0;
    break;
    case 101:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+96;
                        yOffset = int(guiSize.y * (100.0/100))-8;
                        layer = 1.0;
    break;
    case 102:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+32;
                        yOffset = int(guiSize.y * (100.0/100))-8;
                        layer = 1.0;
    break;
    case 103:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-32;
                        yOffset = int(guiSize.y * (100.0/100))-8;
                        layer = 1.0;
    break;
    case 104:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-96;
                        yOffset = int(guiSize.y * (100.0/100))-8;
                        layer = 1.0;
    break;
    case 105:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+160;
                        yOffset = int(guiSize.y * (100.0/100))-72;
                        layer = 1.0;
    break;
    case 106:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+96;
                        yOffset = int(guiSize.y * (100.0/100))-72;
                        layer = 1.0;
    break;
    case 107:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+32;
                        yOffset = int(guiSize.y * (100.0/100))-72;
                        layer = 1.0;
    break;
    case 108:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-32;
                        yOffset = int(guiSize.y * (100.0/100))-72;
                        layer = 1.0;
    break;
    case 109:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-96;
                        yOffset = int(guiSize.y * (100.0/100))-72;
                        layer = 1.0;
    break;
    case 110:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+78;
                        yOffset = int(guiSize.y * (100.0/100))-42;
                        layer = 2.0;
    break;
    case 111:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+14;
                        yOffset = int(guiSize.y * (100.0/100))-42;
                        layer = 2.0;
    break;
    case 112:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-50;
                        yOffset = int(guiSize.y * (100.0/100))-42;
                        layer = 2.0;
    break;
    case 113:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-114;
                        yOffset = int(guiSize.y * (100.0/100))-42;
                        layer = 2.0;
    break;
    case 114:
                        scale.x = 0.2;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))+15;
                        yOffset = int(guiSize.y * (100.0/100))-55;
                        layer = 3.0;
    break;
    case 115:
                        scale.x = 0.25;
                        scale.y = 0.25;
                        xOffset = int(guiSize.x * (-50.0/100))-39;
                        yOffset = int(guiSize.y * (100.0/100))-55;
                        layer = 3.0;
    break;
}


        // -2800.0 is required for forge comp
        if ((Position.z != 1000.0 && Position.z != -2800.0) || outlined) {
            pos.y -= (id*1000) + 500 + MH_OFFSET;
            pos.x -= (guiSize.x * 0.5);

            if (ffNightmareResponsive) pos.x -= 159.0;
            pos.x *= scale.x;
            pos.y *= scale.y;

            pos.y += guiSize.y;
            // force align guiScale 3
            if (guiScale == 3 && !ffNightmareResponsive) {
                pos.x += 1.45;
            }

            pos -= vec3(xOffset, yOffset, 0.0);
            pos.z += layer;
            // Keep the completed frame, HP fill and text together on resize.
            // At most62% of viewport width and22% of viewport height.
            if (ffNightmareResponsive) {
                float ffFit = min(1.0, min(guiSize.x * 0.62 / 320.0,
                                          guiSize.y * 0.22 / 76.0));
                vec2 ffAnchor = vec2(guiSize.x * 0.5, 8.0);
                pos.xy = ffAnchor + (pos.xy - ffAnchor) * ffFit;
            }
        }
    } else if (XP_HIDE) {
        int offset = int(round(guiSize.y - Position.y));
        int vID = gl_VertexID % 4;

        if ((within(Color.rgb, XP_COLOR, 0.002) && is_at(offset, vID, 26, 27)) || (within(Color.rgb, XP_COLOR_SHADOW, 0.002) && is_at(offset, vID, 25, 26, 27, 28))) {
            pos += XP_OFFSET;
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
